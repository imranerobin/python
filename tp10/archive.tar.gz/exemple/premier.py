age = int(input("Saisir votre age: "))
if age >= 18:
	print("Vous êtes majeur")
else:
	print("Vous êtes mineur")
